import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "projeto_lutadores_login.settings")
django.setup()

from django.contrib.auth.models import User

usuarios = [
    ("johnwik25", "nerdgeek"),
    ("manolo123", "qwe123"),
]

for username, senha in usuarios:
    if not User.objects.filter(username=username).exists():
        User.objects.create_user(username=username, password=senha)
        print(f"Usuário '{username}' criado com sucesso.")
    else:
        print(f"Usuário '{username}' já existe.")
