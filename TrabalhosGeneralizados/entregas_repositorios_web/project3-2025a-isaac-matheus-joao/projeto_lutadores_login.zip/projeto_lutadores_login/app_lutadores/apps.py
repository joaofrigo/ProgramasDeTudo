from django.apps import AppConfig

class AppLutadoresConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_lutadores'

  # def ready(self):
    #     from django.contrib.auth import get_user_model
    #     User = get_user_model()
    #     users = [
    #         ('manolo123', 'qwe123'),
    #         ('johnwick25', 'nerdgeek'),
    #     ]
    #     for username, pwd in users:
    #         if not User.objects.filter(username=username).exists():
    #             User.objects.create_user(username=username, password=pwd)
